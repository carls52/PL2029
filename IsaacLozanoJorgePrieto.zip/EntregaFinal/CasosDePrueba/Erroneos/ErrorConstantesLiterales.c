#define Texto1 "Comienzo por dobles comillas y sin finalizacion
#define Texto2 Este string no comienza por una comilla'
#define Texto3 'En cambio este no finaliza en comilla
#define Texto4 "Dobles comillas tanto al comienzo como al final"
int main(void) {
	return 0;
}