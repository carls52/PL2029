int main(void) {
int a;
int b;
int c;
int d;
int e;
int f;
a = 0.x34
b = xFFF
c = 0x,023
d = +0,1
e = x60
f = 0xHgbhjnhbg
return 0;
}