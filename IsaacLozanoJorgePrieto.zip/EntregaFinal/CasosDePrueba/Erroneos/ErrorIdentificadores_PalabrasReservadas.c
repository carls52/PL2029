int main(void) {
float nombre.variable;
int este@nombre@falla;
return esta#var;
if (~id){}
do~while
return;
}