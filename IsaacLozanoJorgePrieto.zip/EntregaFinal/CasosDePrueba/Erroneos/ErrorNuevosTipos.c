#define Texto1 "Mala definicion de array
#define Texto2 float estado.inicial;
int main(void) {
int a;
a = 0.x07 
int var@aux@3;
float xABC;
xABC = 0x,541
return var#4;
int c = +7,5
if (~id){}
do~while
int e = x3476
return 0;
}