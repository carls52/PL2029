#define Texto1 'Este es un string con  'comillas dentro''
#define Texto2 'contenido de la constante literal'
#define Texto3 'contenido con \'contenido\' entrecomillado'
/* 2342
PaioASbasjHASJa s SH1 3E23JE2 323J42 34J2H3BEI32 EI3UBS "�$%&/()=?�)*^�
oiujhfgdsc
*/
//PRUEBA
/* @ */
#define Texto4 'En este string hay una @'
#define Texto5 'En este string hay un //comentario de linea'
#define Texto6 'En este string hay un /*comentario de varias lineas*/'

int main(void){
	return 0;
}
