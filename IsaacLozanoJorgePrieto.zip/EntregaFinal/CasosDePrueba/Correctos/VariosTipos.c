#define VARIABLE 150

int main(void)
{
float prueba;
return 4;
/* , { } + - * / %
'Este es un string con  'comillas dentro''
078 +234 056 0
+54 043.65 0x87.65A 0x-34 */

//Comentario de prueba

int manzanas;
int nachos;
int naranjas;

if ( manzana > 23 ){
do {
manzana = manzana + 2;
}
until ( peras == 56 )
} 
else {
	return 2;
}

if ( manzanas >= nachos ) 
{
manzanas = nachos * 2;
} 
else 
{
 return 6;
}

if ( !naranjas == nachos || manzanas == nachos  && manzanas <= 0  ) {
manzanas = 0;
}
else {
return 7;
}

return 0;
}
