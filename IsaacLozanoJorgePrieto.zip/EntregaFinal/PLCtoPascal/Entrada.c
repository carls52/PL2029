#define prueba 5
#define pruebaa 'bhdwjkcbhdwjkb c djachdwj \' bncjadklncdskla'

int paco(int a,int b) {
	int a;
	a = 78;
	int b;
	b = +234;
	int c;
	c = 056;
	int d;
	d = 0;
	float e;
	e = 043.65;
	float f;
	f = 0x87.65A;
	int g;
	g = 0x-34;
	int g;
	g = +123;
	int i;
	i = -69;
	int j;
	j = 45;
	int k;
	k = 0+123;
	int l;
	l = 0-64;
	int m;
	m = 0x+123;
	int n;
	n = 0x-A6F9;
	int o;
	o = 0xFFFF;
	float p;
	p = +123.456;
	float q;
	q = 045.16;
	float r;
	r = 00.35;
	float s;
	s = 0x+123.0;
	float t;
	t = 0x-E.A6F9;
	float u;
	u = 0x0.FFFF;
int c;
float aqw;
float as;
float qweq;
float dqw;
float qwdq;
int z;
int y;
int m;
float qwdq;
int l;
a = a + b;
return a;
}
int pal(float a,int b){
a = a + b;
return a;
}
int pal1(float a){
a = a + b;
return a;
}
int pal2(int b){
a = a + b;
return a;
}
void prueba(void)
{
int a;
}
void pruebasa(int f, float res)
{
int a;
}
float pruebasa(int f, int res)
{
int a;
return a;
}
float pruebasa(int f, float res)
{
int a;
a();
return a;
}
float pruebasa(int f, float res,int f1, float res1,int f2, float res2)
{
int a;
a();
return a;
}
int buena(void)
{
int i;
for(i = 0; i < 5; i = i - 1)
{
	int a, b;
	a = a + 1;
}
for(i = 0; k < 5; i = i * 3)
{
	int a, b;
	a = a + 1;
}
for(i = 0; i < 5; i = i * 3)
{
	int a, b;
	a = a + 1;
}
for(i = 0; i < 5; i = i + 1)
{
	int a, b;
	a = a + 1;
	if ( a == 4 )
	{
	   a = 3;
	}
	else
	{
	   a = 6;
	}
	if ( a < 4 )
	{
	   a = pepe();
	}
	else
	{
	   a = (a + 6);
	}
	if ( a <= 4 )
	{
	   a = pepe(a + 1, b % 3);
	}
	else
	{
	   a = 6;
	}
}
int j;
i = 4;

do{
 i = i * 1;
}
until( i == 5 )

while(i == 0)
{
i = i / 1;
}
int x;
int y;
while(x<5 && y>3 || !y==3)
{
x = x + 1;
}
while(! x<3)
{
y = y % 1;
}
return a;
}

int main(void) {
a = a + b;
return a;
} 
