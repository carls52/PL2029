package plctopascal;

public class Defines
{
String valor="";
public Defines()
{
}

}