package plctopascal;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

public class Sentlist
{
 String valor = "";
 Map<String,Integer> M = new LinkedHashMap<String,Integer>();
public Sentlist()
{
  
}

}