package plctopascal;

public class Blq
{
String valor = "";
String declaraciones = "";
String entero = "";
String doble = "";
public Blq()
{
    
}

}