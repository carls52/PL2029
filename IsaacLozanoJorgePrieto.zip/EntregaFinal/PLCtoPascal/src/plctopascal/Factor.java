package plctopascal;

public class Factor
{
 String valor = "";
public Factor()
{
    
}

}