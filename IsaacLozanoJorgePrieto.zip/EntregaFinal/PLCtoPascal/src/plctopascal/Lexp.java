package plctopascal;

public class Lexp
{
String valor = "";
public Lexp()
{
}

}