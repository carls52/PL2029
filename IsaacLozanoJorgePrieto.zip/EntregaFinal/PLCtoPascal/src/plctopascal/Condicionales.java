package plctopascal;

public class Condicionales
{
 String valor = "";
public Condicionales()
{
    
}

}