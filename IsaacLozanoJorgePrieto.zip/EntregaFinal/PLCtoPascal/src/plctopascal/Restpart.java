package plctopascal;

public class Restpart
{
 String valor = "";
 String bloque = "";
 String retorno = "";
 Boolean libreria = true;
public Restpart()
{
    
}

}