package plctopascal;

public class Constantes
{
 String valor = "";
public Constantes()
{
}

}