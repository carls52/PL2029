package plctopascal;

public class Operadores
{
 String valor = "";
public Operadores()
{
}

}