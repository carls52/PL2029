package plctopascal;

public class Simbolo
{
 Boolean val;
public Simbolo()
{
}
public Boolean getValor()
{
    return val;
}
}