package plctopascal;

public class Identificadores
{
String valor = "";
public Identificadores()
{
}

}