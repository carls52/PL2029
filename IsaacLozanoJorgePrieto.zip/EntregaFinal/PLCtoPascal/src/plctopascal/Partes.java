package plctopascal;

public class Partes
{
 String valor = "";
 Boolean libreria = true;
public Partes()
{
}

}