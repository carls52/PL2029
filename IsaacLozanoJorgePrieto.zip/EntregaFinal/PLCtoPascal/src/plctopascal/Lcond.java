package plctopascal;

public class Lcond
{
 String valor = "";
public Lcond()
{
    
}

}