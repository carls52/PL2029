package plctopascal;

public class Tipo
{
 String valor = "";
public Tipo()
{
}

}