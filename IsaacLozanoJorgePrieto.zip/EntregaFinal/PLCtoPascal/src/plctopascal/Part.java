package plctopascal;

public class Part
{
 String valor = "";
 Boolean libreria = true;
public Part()
{
}

}