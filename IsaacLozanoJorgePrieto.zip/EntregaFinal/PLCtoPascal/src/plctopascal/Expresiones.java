package plctopascal;

public class Expresiones
{
 String valor ="";
 String id = "";
 String cmp = "";
 String aum = "";
public Expresiones()
{
    
}

}