package plctopascal;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

public class Sent
{
String valor = "";
String retorno = "";
Map<String,Integer> M = new LinkedHashMap<String,Integer>();
public Sent()
{
  
}

}