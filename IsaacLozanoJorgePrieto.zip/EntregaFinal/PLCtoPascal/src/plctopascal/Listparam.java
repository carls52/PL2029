package plctopascal;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

public class Listparam
{
Map<String,Integer> M = new LinkedHashMap<String,Integer>();
public Listparam()
{
}

}